from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any


MIN_RECOMMENDED_EQUITY_USD: dict[str, float] = {
    "global_etf_rotation": 3_000.0,
    "global_etf_confidence_vol_gate": 3_000.0,
    "tqqq_growth_income": 500.0,
    "soxl_soxx_trend_income": 1_000.0,
    "russell_1000_multi_factor_defensive": 30_000.0,
    "tech_communication_pullback_enhancement": 10_000.0,
    "qqq_tech_enhancement": 10_000.0,
    "mega_cap_leader_rotation_top50_balanced": 10_000.0,
}

SMALL_ACCOUNT_WARNING_REASON = "integer_shares_min_position_value_may_prevent_backtest_replication"


def _coerce_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def normalize_profile(profile: str | None) -> str:
    return str(profile or "").strip().lower()


def get_min_recommended_equity_usd(profile: str | None) -> float | None:
    return MIN_RECOMMENDED_EQUITY_USD.get(normalize_profile(profile))


def build_account_size_diagnostics(
    profile: str | None,
    portfolio_total_equity: float | None,
) -> dict[str, object]:
    min_recommended = get_min_recommended_equity_usd(profile)
    if min_recommended is None:
        return {}

    diagnostics: dict[str, object] = {
        "min_recommended_equity_usd": float(min_recommended),
    }
    total_equity = _coerce_float(portfolio_total_equity)
    if total_equity is None:
        diagnostics["small_account_warning"] = False
        return diagnostics

    diagnostics["portfolio_total_equity"] = total_equity
    warning = total_equity < float(min_recommended)
    diagnostics["small_account_warning"] = warning
    if warning:
        diagnostics["small_account_warning_reason"] = SMALL_ACCOUNT_WARNING_REASON
    return diagnostics


def build_account_size_diagnostics_from_context(
    profile: str | None,
    ctx: Any,
) -> dict[str, object]:
    portfolio = getattr(ctx, "portfolio", None)
    portfolio_total_equity = getattr(portfolio, "total_equity", None)
    if portfolio_total_equity is None:
        market_data = getattr(ctx, "market_data", {}) or {}
        if isinstance(market_data, Mapping):
            snapshot = market_data.get("portfolio_snapshot")
            portfolio_total_equity = getattr(snapshot, "total_equity", None)
    return build_account_size_diagnostics(profile, _coerce_float(portfolio_total_equity))


def _format_money(value: float) -> str:
    return f"${value:,.0f}"


def _translate_or_default(
    translator: Callable[..., str] | None,
    key: str,
    default: str,
    **kwargs: object,
) -> str:
    if translator is None:
        return default.format(**kwargs)
    try:
        translated = translator(key, **kwargs)
    except Exception:
        return default.format(**kwargs)
    if translated == key or translated.startswith(f"{key}("):
        return default.format(**kwargs)
    return translated


def append_account_size_warning(
    text: str,
    diagnostics: Mapping[str, object],
    *,
    translator: Callable[..., str] | None = None,
) -> str:
    message = str(text or "").strip()
    if not diagnostics.get("small_account_warning"):
        return message

    portfolio_total_equity = _coerce_float(diagnostics.get("portfolio_total_equity"))
    min_recommended = _coerce_float(diagnostics.get("min_recommended_equity_usd"))
    if portfolio_total_equity is None or min_recommended is None:
        return message

    reason = _translate_or_default(
        translator,
        f"small_account_warning_reason_{SMALL_ACCOUNT_WARNING_REASON}",
        "integer-share minimum position sizing may prevent backtest replication",
    )
    warning = _translate_or_default(
        translator,
        "small_account_warning_note",
        (
            "small account warning: portfolio equity {portfolio_equity} is below "
            "the recommended {min_recommended_equity}; {reason}"
        ),
        portfolio_equity=_format_money(portfolio_total_equity),
        min_recommended_equity=_format_money(min_recommended),
        reason=reason,
    )
    if not message:
        return warning
    return f"{message} | {warning}"
